# -*- coding: utf-8 -*-
"""
Module for recording streams to disk.

"""

from .rawdata import RawDataRecording