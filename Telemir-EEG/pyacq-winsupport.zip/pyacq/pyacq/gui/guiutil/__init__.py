# -*- coding: utf-8 -*-

#~ from .icons import icons 

from mypyqtgraph import *
import mypyqtgraph
